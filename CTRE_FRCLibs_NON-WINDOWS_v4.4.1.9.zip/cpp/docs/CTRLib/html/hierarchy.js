var hierarchy =
[
    [ "CANSpeedController", null, [
      [ "CANTalon", "class_c_a_n_talon.html", null ]
    ] ],
    [ "CtreCanMap", null, [
      [ "PigeonImu", "class_pigeon_imu.html", null ]
    ] ],
    [ "ErrorBase", null, [
      [ "CANTalon", "class_c_a_n_talon.html", null ],
      [ "PigeonImu", "class_pigeon_imu.html", null ]
    ] ],
    [ "PigeonImu::FusionStatus", "struct_pigeon_imu_1_1_fusion_status.html", null ],
    [ "PigeonImu::GeneralStatus", "struct_pigeon_imu_1_1_general_status.html", null ],
    [ "IGadgeteerUartClient", null, [
      [ "CANTalon", "class_c_a_n_talon.html", null ]
    ] ],
    [ "ITableListener", null, [
      [ "CANTalon", "class_c_a_n_talon.html", null ]
    ] ],
    [ "LiveWindowSendable", null, [
      [ "CANTalon", "class_c_a_n_talon.html", null ]
    ] ],
    [ "CANTalon::MotionProfileStatus", "struct_c_a_n_talon_1_1_motion_profile_status.html", null ],
    [ "MotorSafety", null, [
      [ "CANTalon", "class_c_a_n_talon.html", null ]
    ] ],
    [ "PIDInterface", null, [
      [ "CANTalon", "class_c_a_n_talon.html", null ]
    ] ],
    [ "PIDSource", null, [
      [ "CANTalon", "class_c_a_n_talon.html", null ]
    ] ],
    [ "CANTalon::TrajectoryPoint", "struct_c_a_n_talon_1_1_trajectory_point.html", null ]
];