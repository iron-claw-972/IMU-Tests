var dir_d44c64559bbebec7f509842c48db8b23 =
[
    [ "CANTalon.h", "_c_a_n_talon_8h.html", [
      [ "CANTalon", "class_c_a_n_talon.html", "class_c_a_n_talon" ],
      [ "TrajectoryPoint", "struct_c_a_n_talon_1_1_trajectory_point.html", "struct_c_a_n_talon_1_1_trajectory_point" ],
      [ "MotionProfileStatus", "struct_c_a_n_talon_1_1_motion_profile_status.html", "struct_c_a_n_talon_1_1_motion_profile_status" ]
    ] ],
    [ "PigeonImu.h", "_pigeon_imu_8h.html", [
      [ "PigeonImu", "class_pigeon_imu.html", "class_pigeon_imu" ],
      [ "FusionStatus", "struct_pigeon_imu_1_1_fusion_status.html", "struct_pigeon_imu_1_1_fusion_status" ],
      [ "GeneralStatus", "struct_pigeon_imu_1_1_general_status.html", "struct_pigeon_imu_1_1_general_status" ]
    ] ]
];