var annotated_dup =
[
    [ "CANTalon", "class_c_a_n_talon.html", "class_c_a_n_talon" ],
    [ "PigeonImu", "class_pigeon_imu.html", "class_pigeon_imu" ]
];