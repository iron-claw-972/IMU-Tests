var searchData=
[
  ['nomotionbiascount',['noMotionBiasCount',['../struct_pigeon_imu_1_1_general_status.html#adcd54168a45a133634f2758723a62bcc',1,'PigeonImu::GeneralStatus']]]
];
