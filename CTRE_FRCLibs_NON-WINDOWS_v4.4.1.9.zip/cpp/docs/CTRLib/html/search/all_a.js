var searchData=
[
  ['lasterror',['lastError',['../struct_pigeon_imu_1_1_fusion_status.html#a441ba9a153a21bef98f8eeeba7c33d90',1,'PigeonImu::FusionStatus::lastError()'],['../struct_pigeon_imu_1_1_general_status.html#aebbffddb320a62582f6960c651a32793',1,'PigeonImu::GeneralStatus::lastError()']]]
];
