var searchData=
[
  ['calibrationerror',['calibrationError',['../struct_pigeon_imu_1_1_general_status.html#a1f603e10aba28f68f1f50d8f6fa17d5c',1,'PigeonImu::GeneralStatus']]],
  ['currentmode',['currentMode',['../struct_pigeon_imu_1_1_general_status.html#ac18aec7b326be9680375293dbc26bac8',1,'PigeonImu::GeneralStatus']]]
];
