var searchData=
[
  ['ready',['Ready',['../class_pigeon_imu.html#af08e19459beb068e840719205fa46c39a35c07ceb7f4219956413aa7d6cceb8f1',1,'PigeonImu']]],
  ['reset',['Reset',['../class_c_a_n_talon.html#acb83bdcca65d305472d1f7c23ae6d2ee',1,'CANTalon']]]
];
