var searchData=
[
  ['addfusedheading',['AddFusedHeading',['../class_pigeon_imu.html#aa83b1c10badcc495e5a29b520b0a6ac7',1,'PigeonImu']]],
  ['addyaw',['AddYaw',['../class_pigeon_imu.html#af2a22a05165f430d3ab312ac5691cb86',1,'PigeonImu']]]
];
