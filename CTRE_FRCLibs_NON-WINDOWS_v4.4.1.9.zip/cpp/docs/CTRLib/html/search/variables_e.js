var searchData=
[
  ['velocity',['velocity',['../struct_c_a_n_talon_1_1_trajectory_point.html#a4be656118b6bd54bc33ceb55ab1aac6b',1,'CANTalon::TrajectoryPoint']]],
  ['velocityonly',['velocityOnly',['../struct_c_a_n_talon_1_1_trajectory_point.html#a6d15bfa2f22505ffc2ec14774c2705a0',1,'CANTalon::TrajectoryPoint']]]
];
