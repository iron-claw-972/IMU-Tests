var searchData=
[
  ['bcalisbooting',['bCalIsBooting',['../struct_pigeon_imu_1_1_general_status.html#ae453f6468362fd4162f74619d214ae2e',1,'PigeonImu::GeneralStatus']]],
  ['bisfusing',['bIsFusing',['../struct_pigeon_imu_1_1_fusion_status.html#a26dd4c21e27118aa1eb9efffe4059f48',1,'PigeonImu::FusionStatus']]],
  ['bisvalid',['bIsValid',['../struct_pigeon_imu_1_1_fusion_status.html#a09db898f92aece7aa8e26d9e181cbafd',1,'PigeonImu::FusionStatus']]],
  ['boottaregyroaccel',['BootTareGyroAccel',['../class_pigeon_imu.html#a1d73ea84ad5c812e809698fab0b9b490ac5ffb1e16d3c2da1382893006c47a221',1,'PigeonImu']]],
  ['btmbuffercnt',['btmBufferCnt',['../struct_c_a_n_talon_1_1_motion_profile_status.html#a597c83906bfbab8fe0cfbe37146a3741',1,'CANTalon::MotionProfileStatus']]]
];
