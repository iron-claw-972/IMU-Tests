var searchData=
[
  ['description',['description',['../struct_pigeon_imu_1_1_fusion_status.html#a3aec3a1a6919d3e47dcc48e2f1032317',1,'PigeonImu::FusionStatus::description()'],['../struct_pigeon_imu_1_1_general_status.html#a146df77af7a6c0a7f622009dfd0ce5b7',1,'PigeonImu::GeneralStatus::description()']]]
];
