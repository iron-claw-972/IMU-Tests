var searchData=
[
  ['activepoint',['activePoint',['../struct_c_a_n_talon_1_1_motion_profile_status.html#aef26cca61965cb71161eb2df52982c80',1,'CANTalon::MotionProfileStatus']]],
  ['activepointvalid',['activePointValid',['../struct_c_a_n_talon_1_1_motion_profile_status.html#ad6af70d14a610a0392186f19c52f036b',1,'CANTalon::MotionProfileStatus']]]
];
