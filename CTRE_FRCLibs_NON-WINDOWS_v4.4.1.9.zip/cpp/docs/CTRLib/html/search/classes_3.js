var searchData=
[
  ['motionprofilestatus',['MotionProfileStatus',['../struct_c_a_n_talon_1_1_motion_profile_status.html',1,'CANTalon']]]
];
